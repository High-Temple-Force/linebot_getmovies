const { Datastore } = require('@google-cloud/datastore')
const projectId = 'linebot-get-movies'
const datastore = new Datastore({
    projectId : projectId,
})

const kind = 'Movies'
const name = 'samplemovie1'
const taskKey = datastore.key([kind, name])

const task = {
    key: taskKey,
    data: {
        name: 'アリー',
    },
}

exports.testDATA = (req, res) => {    
    datastore.save(task).then(() => {
        res.send(`Saved ${task.key.name} : ${task.data.name}`)
    })
    .catch(err => {
        res.send('Error,' , err)
    })
}
